package selectRecordsUsingPagination;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import beans.Product;

/**
 * Servlet implementation class PageServlet
 */
/*
public class PageServlet extends HttpServlet 
{
	
	 Session ses=null;
	 int initValue;
	 int totalRecords;
	 
    public PageServlet() {
        // TODO Auto-generated constructor stub
    }
    public void init(){
    	try{
    	ses=new Configuration().buildSessionFactory().openSession();
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Query q1=ses.createQuery("Select eb from EmpBean as eb ");
		  q1.setFirstResult(initValue);
		  q1.setMaxResults(2);
		 List l1=q1.list();
		 totalRecords=l1.size();
//create/locate session for Client
		 HttpSession se=request.getSession();
		 if(se.getAttribute("counter")==null){
//Logic for first record			 
			 se.setAttribute("counter",new Integer(initValue));
		 }
		 else{
//Logic for other than first record
			 Integer i1=(Integer)se.getAttribute("counter");
			 initValue=i1.intValue()+2;
			 se.setAttribute("initValue",new Integer(initValue));
		 }
		 //Logic to display records in the form of html table by applying pagination.
		  PrintWriter pw=response.getWriter();
		  RequestDispatcher rd=request.getRequestDispatcher("s2");
		  rd.include(request,response);
//Logic to display Home as next HyperLinks 
		  if((initValue+2)<totalRecords){
			  pw.println("<a href='pageurl'>Next</a>");
		  }
		  else{
			  pw.println("<a href='input.html'>Home</a>");
              se.invalidate();
		  }
		  pw.close();
 }
	public void destroy(){
		try{
			ses.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
*/
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.util.Iterator;
	import java.util.List;

	import javax.servlet.ServletConfig;
	import javax.servlet.ServletException;
	import javax.servlet.ServletRequest;
	import javax.servlet.ServletResponse;
	import javax.servlet.http.HttpServlet;

	import org.hibernate.Criteria;
	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.cfg.Configuration;
	import org.hibernate.criterion.Projections;

	public class Pagination extends HttpServlet{
	SessionFactory factory;
	//init method started
	public void init(ServletConfig config)throws ServletException
	{
	factory = new Configuration().configure().buildSessionFactory();
	System.out.println("Factory has been created....");
	}
	//init method end

	//service method start
	public void service(ServletRequest req, ServletResponse res)
	throws ServletException,IOException{
		int pageIndex = 0;
		int totalNumberOfRecords = 0;
		int numberOfRecordsPerPage = 4;
		String sPageIndex = req.getParameter("pageIndex");
		if(sPageIndex ==null){
			pageIndex = 1;
		}
		else{
			pageIndex = Integer.parseInt(sPageIndex);
		}
		Session ses = factory.openSession();
		int s = (pageIndex*numberOfRecordsPerPage) -numberOfRecordsPerPage;
		Criteria crit = ses.createCriteria(Product.class);
		crit.setFirstResult(s);
		crit.setMaxResults(numberOfRecordsPerPage);
		List l = crit.list();
		Iterator it = l.iterator();
		PrintWriter pw = res.getWriter();
		pw.println("<table border=1>");
		pw.println("<tr>");
		pw.println("<th>PID</th><th>PNAME</th><th>PRICE</th>");
		pw.println("</tr>");
		while(it.hasNext()){
			Product p = (Product)it.next();
			pw.println("<tr>");
			pw.println("<td>"+p.getProductId()+"</td>");
			pw.println("<td>"+p.getProName()+"</td>");
			pw.println("<td>"+p.getPrice()+"</td>");
			pw.println("</tr>");
		}
		pw.println("<table>");
		Criteria crit1 = ses.createCriteria(Product.class);
		crit1.setProjection(Projections.rowCount());
		List l1=crit1.list();
	// pw.println(l1.size());
	//returns 1, as list() is used to execute the query if true will returns 1
		Iterator it1 = l1.iterator();
		if(it1.hasNext()){
			Object o=it1.next();
			totalNumberOfRecords = Integer.parseInt(o.toString());
		}
		int noOfPages = totalNumberOfRecords/numberOfRecordsPerPage;
		if(totalNumberOfRecords > (noOfPages * numberOfRecordsPerPage)){
			noOfPages = noOfPages + 1;
		}
		for(int i=1;i<=noOfPages;i++){
			String myurl = "ind?pageIndex="+i;
			pw.println("<a href="+myurl+">"+i+"</a>");
		}
		ses.close();
		pw.close();
	}
	 
	public void destroy()
	{
	factory.close();
	}
	//destroy end
	}
