package selectRecordUsingScalerQuery;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
//Using HQL if you want to dump old Tabel Data into New Table Data.
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import beans.StudentOld;

public class ClientNew 
{
	public static void main(String[] args){
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
 
//Native Scaler	Query
		String hql="select max(sid) as mval from StudentOld";
		//String hql="select max(sid) as mval,count(*) as cnt from StudentOld";
		//String hql="select name,marks from StudentOld where email like :p1";

 		SQLQuery q=s.createSQLQuery(hql);
		//q.setString("p1","%gmail.com");
//Map NativeScaler Query results with Hibernate DataTypes.		
		//q.addScaler("firstname",Hibernate.String);
		//q.addScaler("lastname",Hibernate.String);
		//q.addEntity("e",StudentOld.class);

//Execute NativeSqlQuery		
		 List l1=q.list();
//Display records
		 for(int i=0;i<l1.size();i++){
			 Object[] sto=(Object[])l1.get(i);
			 //if(sto.getId()!=0)
			// System.out.println(sto.getId());
			// if(sto.getEmail()!=null)
			// System.out.println(sto.getEmail());
			 
			 for(int k=0;k<sto.length;k++){
			 if(((StudentOld) sto[k]).getMarks()!=0)
			 System.out.println(((StudentOld) sto[k]).getMarks());
			 if(((StudentOld) sto[k]).getName()!=null)
				 System.out.println(((StudentOld) sto[k]).getName());
		 }
 	}
}
}
