package selectAllRecordsUsingNativeEntityHql;

import java.util.List;

import org.hibernate.SQLQuery;
//Using HQL if you want to dump old Tabel Data into New Table Data.
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import beans.StudentOld;

public class ClientNew 
{
	public static void main(String[] args){
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
//hql1=" from StudentOld as so";hql2=from StudentOld so;hq3=select sob from StudentOld as sob';hql4='from StudentOld';
//hql4="Select eb.eid,eb.name	
		//String hql="select {e.*} from StudentOld as e";
		//String hql="select * from StudentOld";
//Native Entity	Query
		String hql="select * from StudentOld where sid>=? and sid<=:p1";

//Map Entity Query with HibernatePojo class		
		SQLQuery q=s.createSQLQuery(hql);
		q.setInteger(0,2);
		q.setInteger("p1",8);
		q.addEntity("e",StudentOld.class);
//Execute NativeSqlQuery		
		 List l1=q.list();
//Display records
		 for(int i=0;i<l1.size();i++){
			 StudentOld sto=(StudentOld)l1.get(i);
			 //if(sto.getId()!=0)
			// System.out.println(sto.getId());
			// if(sto.getEmail()!=null)
			// System.out.println(sto.getEmail());
			// if(sto.getName()!=null)
			 //System.out.println(sto.getName());
			 if(sto.getMarks()!=0)
			 System.out.println(sto.getMarks());
		 }
 	}
}
