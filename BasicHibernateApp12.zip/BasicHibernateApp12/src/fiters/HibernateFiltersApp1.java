package fiters;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Filter;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import beans.StudentOld;

public class HibernateFiltersApp1 {
	public static void main(String[] s){
		List l=null;
		//Student Object state is transient
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session sess=sf.openSession();
//enable filter on Hibernate Session Object

		Filter filter=sess.enableFilter("myfilter");
//To disable filter on HibernateSessionObject
		//sess.disableFilter("myfilter");
	
		filter.setParameter("myid1",new Integer(10));
		filter.setParameter("myid2",new Integer(20));
//HQL query
		Criteria crit=sess.createCriteria(StudentOld.class);
		List l1=crit.list();
		for(int i=0;i<l1.size();i++){
	    	   StudentOld so=(StudentOld)l1.get(i);
	    	   if(so.getName()!=null)
	    	   System.out.println(so.getName());
	    	   if(so.getEmail()!=null)
	    	   System.out.println(so.getEmail());
	    	   if(so.getMarks()!=0)
	    	   System.out.println(so.getMarks());
	       }
	}
}
