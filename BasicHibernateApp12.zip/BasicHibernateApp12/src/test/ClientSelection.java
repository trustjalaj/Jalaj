package test;
//select all column values of a table
 import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
  
import beans.StudentOld;

public class ClientSelection 
{

	public static void main(String[] args) {
		List l=null;
		//Student Object state is transient
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		//Since the method has been depreciated we will not use it.
		Criteria cp=s.createCriteria(StudentOld.class);
		 l=cp.list();
       for(int i=0;i<l.size();i++){
    	   StudentOld so=(StudentOld)l.get(i);
    	   if(so.getName()!=null)
    	   System.out.println(so.getName());
    	   if(so.getEmail()!=null)
    	   System.out.println(so.getEmail());
    	   if(so.getMarks()!=0)
    	   System.out.println(so.getMarks());
       }
	}
}
