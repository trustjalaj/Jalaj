package usingXml;

import org.hibernate.*;  
import org.hibernate.cfg.*;

import usingXml.Cheque;
import usingXml.CreditCard;

   
public class StoreData {
public static void main(String[] args) {  
    Configuration cfg=new Configuration();  
    Session session=cfg.configure("hibernate.cfg.xml").buildSessionFactory().openSession();  
      
    Transaction t=session.beginTransaction();  
      
    CreditCard c=new CreditCard();
    
    c.setPaymentId(10);
    c.setAmount(2500);
    c.setCreditCardType("Visa");


    
    Cheque c1=new Cheque();
    
    c1.setPaymentId(11);
    c1.setAmount(2600);
    c1.setChequeType("ICICI");

    
    session.save(c);
    session.save(c1);
    System.out.println("Object saved successfully.....!!");
    t.commit();
    session.close();  
    System.out.println("success");  
}  
}  